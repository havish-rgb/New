package com.jarvis.app

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Prefs {
    fun get(context: Context): SharedPreferences {
        val masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
        return EncryptedSharedPreferences.create(
            "jarvis",
            masterKeyAlias,
            context,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }
}

object Brain {
    fun ask(context: Context, system: String, user: String): String {
        val prefs = Prefs.get(context)
        val apiKey = prefs.getString("key", "").orEmpty()
        require(apiKey.isNotBlank()) { "Add your AI API key in JARVIS settings first." }

        val body = JSONObject()
            .put("model", prefs.getString("model", "anthropic/claude-sonnet-4.5"))
            .put(
                "messages",
                JSONArray()
                    .put(JSONObject().put("role", "system").put("content", system))
                    .put(JSONObject().put("role", "user").put("content", user))
            )

        val connection = URL(
            prefs.getString("endpoint", "https://openrouter.ai/api/v1/chat/completions")
                ?: "https://openrouter.ai/api/v1/chat/completions"
        ).openConnection() as HttpURLConnection

        try {
            connection.requestMethod = "POST"
            connection.doOutput = true
            connection.connectTimeout = 20_000
            connection.readTimeout = 60_000
            connection.setRequestProperty("Authorization", "Bearer $apiKey")
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")

            connection.outputStream.use { output ->
                output.write(body.toString().toByteArray(Charsets.UTF_8))
            }

            val responseCode = connection.responseCode
            val responseStream = if (responseCode in 200..299) {
                connection.inputStream
            } else {
                connection.errorStream
            }
            val responseText = responseStream?.bufferedReader()?.use { it.readText() }.orEmpty()

            if (responseCode !in 200..299) {
                throw IllegalStateException("AI API error ($responseCode): $responseText")
            }

            return JSONObject(responseText)
                .getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .getString("content")
        } finally {
            connection.disconnect()
        }
    }

    fun json(value: String): JSONObject {
        val start = value.indexOf('{')
        val end = value.lastIndexOf('}')
        require(start >= 0 && end > start) { "No JSON object found in response." }
        return JSONObject(value.substring(start, end + 1))
    }
}

object Memory {
    fun all(context: Context): String = Prefs.get(context).getString("mem", "").orEmpty()

    fun add(context: Context, fact: String) {
        val updated = (all(context) + "\n- " + fact).takeLast(8_000)
        Prefs.get(context).edit().putString("mem", updated).apply()
    }

    fun clear(context: Context) {
        Prefs.get(context).edit().remove("mem").apply()
    }
}
